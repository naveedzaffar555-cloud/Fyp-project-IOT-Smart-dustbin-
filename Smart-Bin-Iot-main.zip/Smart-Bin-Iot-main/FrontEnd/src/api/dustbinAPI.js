import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

const mockData = {
  status: {
    id: 1,
    fill_level: 74,
    gas_value: 123,
    gas_status: "Warning",
    battery: 82,
    wifi_status: "Connected",
    signal_strength: "Excellent",
    updated_at: new Date().toISOString(),
    last_sync: "5 seconds ago"
  },
  logs: [
    {
      id: 1,
      timestamp: "20:15",
      fill_level: 74,
      gas_value: 123,
      status: "Warning",
      date: "2025-12-11T20:15:00"
    },
    {
      id: 2,
      timestamp: "19:50",
      fill_level: 65,
      gas_value: 80,
      status: "Safe",
      date: "2025-12-11T19:50:00"
    },
    {
      id: 3,
      timestamp: "19:15",
      fill_level: 80,
      gas_value: 105,
      status: "Warning",
      date: "2025-12-11T19:15:00"
    },
    {
      id: 4,
      timestamp: "18:45",
      fill_level: 58,
      gas_value: 75,
      status: "Safe",
      date: "2025-12-11T18:45:00"
    },
    {
      id: 5,
      timestamp: "18:10",
      fill_level: 50,
      gas_value: 68,
      status: "Safe",
      date: "2025-12-11T18:10:00"
    }
  ],
  alerts: [
    {
      id: 1,
      type: "critical",
      message: "Gas level high — check immediately",
      timestamp: "2 min ago"
    },
    {
      id: 2,
      type: "warning",
      message: "Dustbin fill level at 74% — plan collection soon",
      timestamp: "15 min ago"
    }
  ]
};

export const getDustbinStatus = async (deviceId = 1) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/dustbin/status/${deviceId}`);
    return response.data;
  } catch (error) {
    console.warn('API not available, using mock data:', error.message);
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockData.status), 800);
    });
  }
};

export const getDustbinLogs = async (deviceId = 1) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/dustbin/logs/${deviceId}`);
    return response.data;
  } catch (error) {
    console.warn('API not available, using mock data:', error.message);
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockData.logs), 800);
    });
  }
};

export const getAlerts = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/dustbin/alerts`);
    return response.data;
  } catch (error) {
    console.warn('API not available, using mock data:', error.message);
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockData.alerts), 800);
    });
  }
};
