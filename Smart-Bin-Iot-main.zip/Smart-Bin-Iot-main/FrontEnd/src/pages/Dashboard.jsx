import { useState, useEffect } from 'react';
import FillLevelCard from '../components/FillLevelCard';
import GasStatusCard from '../components/GasStatusCard';
import DeviceStatusCard from '../components/DeviceStatusCard';
import AlertList from '../components/AlertList';
import MapScreenshotCard from '../components/MapScreenshotCard';
import LogTable from '../components/LogTable';
import { getDustbinStatus, getDustbinLogs, getAlerts } from '../api/dustbinAPI';

const Dashboard = () => {
  const [status, setStatus] = useState(null);
  const [logs, setLogs] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [statusData, logsData, alertsData] = await Promise.all([
        getDustbinStatus(1),
        getDustbinLogs(1),
        getAlerts()
      ]);

      setStatus(statusData);
      setLogs(logsData);
      setAlerts(alertsData);
      setError(null);
    } catch (err) {
      setError('Failed to fetch data. Please try again.');
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-8">
        {error && (
          <div className="mb-6 bg-red-500/10 border border-red-500/30 rounded-2xl p-4">
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <FillLevelCard
            fillLevel={status?.fill_level || 0}
            loading={loading}
          />
          <GasStatusCard
            gasValue={status?.gas_value || 0}
            gasStatus={status?.gas_status || 'Unknown'}
            loading={loading}
          />
          <DeviceStatusCard
            deviceData={{
              battery: status?.battery || 0,
              wifi_status: status?.wifi_status || 'Disconnected',
              signal_strength: status?.signal_strength || 'Unknown',
              last_sync: status?.last_sync || 'Never'
            }}
            loading={loading}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <AlertList alerts={alerts} loading={loading} />
          <MapScreenshotCard
            fillLevel={status?.fill_level || 0}
            gasValue={status?.gas_value || 0}
            gasStatus={status?.gas_status || 'Unknown'}
            loading={loading}
          />
        </div>

        <LogTable logs={logs} loading={loading} />
      </div>
    </div>
  );
};

export default Dashboard;
