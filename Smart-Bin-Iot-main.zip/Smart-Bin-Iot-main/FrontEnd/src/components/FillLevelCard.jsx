import { TrendingUp } from 'lucide-react';

const FillLevelCard = ({ fillLevel, loading }) => {
  const getStatusColor = (level) => {
    if (level >= 80) return 'text-red-400';
    if (level >= 60) return 'text-yellow-400';
    return 'text-green-400';
  };

  const getGradientColor = (level) => {
    if (level >= 80) return 'from-red-500 to-pink-500';
    if (level >= 60) return 'from-yellow-500 to-pink-500';
    return 'from-green-500 to-emerald-500';
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10">
        <div className="animate-pulse">
          <div className="h-6 bg-slate-700 rounded w-1/2 mb-8"></div>
          <div className="flex items-center justify-center">
            <div className="w-48 h-48 bg-slate-700 rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  const circumference = 2 * Math.PI * 85;
  const strokeDashoffset = circumference - (fillLevel / 100) * circumference;

  return (
    <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10 hover:border-pink-500/30 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-gray-400 text-sm font-medium mb-1">Dustbin Fill Level</h3>
          <p className={`text-5xl font-bold ${getStatusColor(fillLevel)}`}>
            {fillLevel}%
          </p>
        </div>
        <div className="bg-gradient-to-br from-pink-500/20 to-purple-500/20 p-4 rounded-2xl">
          <TrendingUp className="w-8 h-8 text-pink-400" />
        </div>
      </div>

      <div className="flex items-center justify-center py-6">
        <div className="relative w-48 h-48">
          <svg className="transform -rotate-90 w-48 h-48">
            <circle
              cx="96"
              cy="96"
              r="85"
              stroke="currentColor"
              strokeWidth="12"
              fill="none"
              className="text-slate-700"
            />
            <circle
              cx="96"
              cy="96"
              r="85"
              stroke="url(#fillGradient)"
              strokeWidth="12"
              fill="none"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="transition-all duration-1000 ease-out"
            />
            <defs>
              <linearGradient id="fillGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" className="text-pink-500" stopColor="currentColor" />
                <stop offset="100%" className="text-purple-500" stopColor="currentColor" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="text-4xl font-bold text-white">{fillLevel}%</div>
              <div className="text-sm text-gray-400 mt-1">Capacity</div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 text-center">
        <p className="text-sm text-gray-400">Updated just now</p>
      </div>
    </div>
  );
};

export default FillLevelCard;
