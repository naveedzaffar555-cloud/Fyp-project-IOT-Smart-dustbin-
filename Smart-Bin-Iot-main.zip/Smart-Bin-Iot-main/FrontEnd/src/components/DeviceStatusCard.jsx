import { Wifi, Battery, Activity } from 'lucide-react';

const DeviceStatusCard = ({ deviceData, loading }) => {
  if (loading) {
    return (
      <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10">
        <div className="animate-pulse">
          <div className="h-6 bg-slate-700 rounded w-1/2 mb-8"></div>
          <div className="space-y-4">
            <div className="h-12 bg-slate-700 rounded"></div>
            <div className="h-12 bg-slate-700 rounded"></div>
            <div className="h-12 bg-slate-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10 hover:border-blue-500/30 transition-all duration-300">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-gray-400 text-sm font-medium mb-1">Device Health</h3>
          <p className="text-2xl font-bold text-white">ID: #DB-2024-X1</p>
        </div>
        <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 p-4 rounded-2xl">
          <Activity className="w-8 h-8 text-blue-400" />
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-2xl border border-white/5">
          <div className="flex items-center gap-4">
            <div className="bg-green-500/20 p-3 rounded-xl">
              <Wifi className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Connection</p>
              <p className="text-sm text-gray-300">Signal Strength: {deviceData.signal_strength}</p>
            </div>
          </div>
          <span className="px-4 py-2 bg-green-500/20 text-green-400 rounded-full text-sm font-medium">
            {deviceData.wifi_status}
          </span>
        </div>

        <div className="flex items-center justify-between p-4 bg-slate-700/30 rounded-2xl border border-white/5">
          <div className="flex items-center gap-4">
            <div className="bg-yellow-500/20 p-3 rounded-xl">
              <Battery className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Battery Level</p>
              <p className="text-sm text-gray-300">Last charge: 2 days ago</p>
            </div>
          </div>
          <span className="text-2xl font-bold text-yellow-400">
            {deviceData.battery}%
          </span>
        </div>

        <div className="p-4 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-2xl border border-purple-500/20">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-400">Last Sync</p>
            <p className="text-sm font-medium text-white">{deviceData.last_sync}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeviceStatusCard;
