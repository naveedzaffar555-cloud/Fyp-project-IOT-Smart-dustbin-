import { Wind } from 'lucide-react';

const GasStatusCard = ({ gasValue, gasStatus, loading }) => {
  const getStatusInfo = (status) => {
    switch (status) {
      case 'Safe':
        return {
          color: 'text-green-400',
          gradient: 'from-green-500 to-emerald-500',
          bgGradient: 'from-green-500/20 to-emerald-500/20',
          threshold: 'Threshold: 100 PPM'
        };
      case 'Warning':
        return {
          color: 'text-purple-400',
          gradient: 'from-purple-500 to-pink-500',
          bgGradient: 'from-purple-500/20 to-pink-500/20',
          threshold: 'Threshold: 100 PPM'
        };
      case 'Danger':
        return {
          color: 'text-red-400',
          gradient: 'from-red-500 to-pink-500',
          bgGradient: 'from-red-500/20 to-pink-500/20',
          threshold: 'Threshold: 100 PPM'
        };
      default:
        return {
          color: 'text-gray-400',
          gradient: 'from-gray-500 to-slate-500',
          bgGradient: 'from-gray-500/20 to-slate-500/20',
          threshold: 'Threshold: 100 PPM'
        };
    }
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10">
        <div className="animate-pulse">
          <div className="h-6 bg-slate-700 rounded w-1/2 mb-8"></div>
          <div className="flex items-center justify-center">
            <div className="w-48 h-48 bg-slate-700 rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  const statusInfo = getStatusInfo(gasStatus);
  const percentage = Math.min((gasValue / 200) * 100, 100);
  const circumference = 2 * Math.PI * 85;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10 hover:border-purple-500/30 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-gray-400 text-sm font-medium mb-1">Gas Status (PPM)</h3>
          <p className={`text-5xl font-bold ${statusInfo.color}`}>
            {gasValue}
          </p>
        </div>
        <div className={`bg-gradient-to-br ${statusInfo.bgGradient} p-4 rounded-2xl`}>
          <Wind className={`w-8 h-8 ${statusInfo.color}`} />
        </div>
      </div>

      <div className="flex items-center justify-center py-6">
        <div className="relative w-48 h-48">
          <svg className="transform -rotate-90 w-48 h-48">
            <circle
              cx="96"
              cy="96"
              r="85"
              stroke="currentColor"
              strokeWidth="12"
              fill="none"
              className="text-slate-700"
            />
            <circle
              cx="96"
              cy="96"
              r="85"
              stroke="url(#gasGradient)"
              strokeWidth="12"
              fill="none"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="transition-all duration-1000 ease-out"
            />
            <defs>
              <linearGradient id="gasGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" className={statusInfo.gradient.split(' ')[0].replace('from-', 'text-')} stopColor="currentColor" />
                <stop offset="100%" className={statusInfo.gradient.split(' ')[1].replace('to-', 'text-')} stopColor="currentColor" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className={`text-3xl font-bold ${statusInfo.color}`}>{gasStatus}</div>
              <div className="text-sm text-gray-400 mt-1">Quality</div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 text-center">
        <p className="text-sm text-gray-400">{statusInfo.threshold}</p>
      </div>
    </div>
  );
};

export default GasStatusCard;
