import { MapPin, Maximize2 } from 'lucide-react';

const MapScreenshotCard = ({ fillLevel, gasValue, gasStatus, loading }) => {
  if (loading) {
    return (
      <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10">
        <div className="animate-pulse">
          <div className="h-6 bg-slate-700 rounded w-1/2 mb-6"></div>
          <div className="h-96 bg-slate-700 rounded-2xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10 hover:border-green-500/30 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-xl font-bold text-white mb-1">Dustbin Location Overview</h3>
          <p className="text-sm text-gray-400">GPS Coordinates: 33.7294° N, 73.1882° E</p>
        </div>
        <button className="p-3 bg-slate-700/50 hover:bg-slate-600/50 rounded-xl transition-colors">
          <Maximize2 className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      <div className="relative rounded-2xl overflow-hidden">
        <img
          src="/image.png"
          alt="Location Map"
          className="w-full h-96 object-cover"
        />

        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>

        <div className="absolute top-4 left-4 right-4 flex items-start justify-between">
          <div className="bg-slate-900/90 backdrop-blur-lg px-4 py-3 rounded-xl border border-white/10">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-green-400" />
              <span className="text-sm font-medium text-white">Active Location</span>
            </div>
          </div>
        </div>

        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-slate-900/90 backdrop-blur-lg p-6 rounded-2xl border border-white/10">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-gray-400 mb-1">Fill Level</p>
                <p className="text-lg font-bold text-pink-400">{fillLevel}%</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 mb-1">Gas Status</p>
                <p className="text-lg font-bold text-yellow-400">{gasStatus}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 mb-1">Last Updated</p>
                <p className="text-lg font-bold text-green-400">Just now</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapScreenshotCard;
