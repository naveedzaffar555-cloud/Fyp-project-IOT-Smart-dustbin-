import { Clock } from 'lucide-react';

const LogTable = ({ logs, loading }) => {
  if (loading) {
    return (
      <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10">
        <div className="animate-pulse">
          <div className="h-6 bg-slate-700 rounded w-1/3 mb-6"></div>
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-12 bg-slate-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const getStatusBadge = (status) => {
    const styles = {
      Safe: 'bg-green-500/20 text-green-400 border-green-500/30',
      Warning: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      Danger: 'bg-red-500/20 text-red-400 border-red-500/30'
    };
    return styles[status] || styles.Safe;
  };

  return (
    <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10">
      <div className="flex items-center gap-3 mb-6">
        <Clock className="w-6 h-6 text-purple-400" />
        <h3 className="text-xl font-bold text-white">Recent System Logs</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-700">
              <th className="text-left py-4 px-4 text-sm font-semibold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                Time
              </th>
              <th className="text-left py-4 px-4 text-sm font-semibold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                Fill Level
              </th>
              <th className="text-left py-4 px-4 text-sm font-semibold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                Gas Value
              </th>
              <th className="text-left py-4 px-4 text-sm font-semibold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                Status
              </th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log, index) => (
              <tr
                key={log.id}
                className="border-b border-slate-800/50 hover:bg-slate-700/20 transition-colors"
              >
                <td className="py-4 px-4 text-gray-300">{log.timestamp}</td>
                <td className="py-4 px-4">
                  <div className="flex items-center gap-2">
                    <div className="w-full max-w-[100px] bg-slate-700 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-pink-500 to-purple-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${log.fill_level}%` }}
                      ></div>
                    </div>
                    <span className="text-gray-300 font-medium">{log.fill_level}%</span>
                  </div>
                </td>
                <td className="py-4 px-4 text-gray-300 font-medium">{log.gas_value} PPM</td>
                <td className="py-4 px-4">
                  <span className={`px-3 py-1.5 rounded-full text-xs font-medium border ${getStatusBadge(log.status)}`}>
                    {log.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LogTable;
