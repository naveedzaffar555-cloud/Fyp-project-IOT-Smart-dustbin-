import { AlertTriangle, AlertCircle, Clock } from 'lucide-react';

const AlertList = ({ alerts, loading }) => {
  if (loading) {
    return (
      <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10">
        <div className="animate-pulse">
          <div className="h-6 bg-slate-700 rounded w-1/3 mb-6"></div>
          <div className="space-y-4">
            <div className="h-16 bg-slate-700 rounded-xl"></div>
            <div className="h-16 bg-slate-700 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  const getAlertStyle = (type) => {
    switch (type) {
      case 'critical':
        return {
          bg: 'bg-red-500/10',
          border: 'border-red-500/30',
          icon: <AlertTriangle className="w-5 h-5 text-red-400" />,
          badge: 'bg-red-500/20 text-red-400',
          text: 'text-red-400'
        };
      case 'warning':
        return {
          bg: 'bg-yellow-500/10',
          border: 'border-yellow-500/30',
          icon: <AlertCircle className="w-5 h-5 text-yellow-400" />,
          badge: 'bg-yellow-500/20 text-yellow-400',
          text: 'text-yellow-400'
        };
      default:
        return {
          bg: 'bg-blue-500/10',
          border: 'border-blue-500/30',
          icon: <AlertCircle className="w-5 h-5 text-blue-400" />,
          badge: 'bg-blue-500/20 text-blue-400',
          text: 'text-blue-400'
        };
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-lg rounded-3xl p-8 shadow-2xl border border-white/10">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-yellow-400" />
          <h3 className="text-xl font-bold text-white">Active Alerts</h3>
        </div>
        <span className="px-4 py-1.5 bg-yellow-500/20 text-yellow-400 rounded-full text-sm font-medium">
          {alerts.length} New
        </span>
      </div>

      <div className="space-y-4">
        {alerts.map((alert) => {
          const style = getAlertStyle(alert.type);
          return (
            <div
              key={alert.id}
              className={`${style.bg} ${style.border} border rounded-2xl p-5 hover:scale-[1.02] transition-all duration-300 cursor-pointer`}
            >
              <div className="flex items-start gap-4">
                <div className={`${style.badge} p-3 rounded-xl`}>
                  {style.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4">
                    <p className="text-white font-medium leading-relaxed">
                      {alert.message}
                    </p>
                    <span className={`${style.badge} px-3 py-1 rounded-full text-xs font-medium uppercase whitespace-nowrap`}>
                      {alert.type}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-400">{alert.timestamp}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AlertList;
