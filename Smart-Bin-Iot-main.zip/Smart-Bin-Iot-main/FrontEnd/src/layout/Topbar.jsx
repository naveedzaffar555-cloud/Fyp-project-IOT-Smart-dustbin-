import { Search, Bell, CircleDot } from 'lucide-react';

const Topbar = () => {
  return (
    <div className="bg-gradient-to-r from-slate-900 to-slate-950 border-b border-slate-800 px-8 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Dashboard Overview</h2>
          <p className="text-sm text-gray-400">Monitor your smart dustbin in real-time</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search devices..."
              className="bg-slate-800/50 border border-slate-700 rounded-xl px-4 py-2.5 pl-10 text-gray-300 placeholder-gray-500 focus:outline-none focus:border-pink-500/50 transition-colors w-64"
            />
            <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>

          <button className="relative p-3 bg-slate-800/50 hover:bg-slate-700/50 rounded-xl transition-colors border border-slate-700">
            <Bell className="w-5 h-5 text-gray-400" />
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>

          <div className="flex items-center gap-3 px-4 py-2.5 bg-slate-800/50 rounded-xl border border-slate-700">
            <CircleDot className="w-4 h-4 text-green-400" />
            <span className="text-sm font-medium text-green-400">System Online</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Topbar;
