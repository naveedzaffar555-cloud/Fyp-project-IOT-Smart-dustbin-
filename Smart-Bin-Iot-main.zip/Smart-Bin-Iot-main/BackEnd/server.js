import express from "express";
import axios from "axios";
import cors from "cors";

const app = express();
const PORT = 3000;

// CHANGE THIS TO YOUR ESP32 IP
const ESP32_BASE_URL = "http://192.168.1.7";

app.use(cors());
app.use(express.json());

/* ---------------- STATUS ---------------- */
app.get("/api/dustbin/status/:id", async (req, res) => {
  try {
    const response = await axios.get(
      `${ESP32_BASE_URL}/api/dustbin/status/${req.params.id}`
    );
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: "ESP32 not reachable" });
  }
});

/* ---------------- LOGS ---------------- */
app.get("/api/dustbin/logs/:id", (req, res) => {
  // Simple live log (can be improved later)
  res.json([
    {
      id: 1,
      timestamp: new Date().toLocaleTimeString(),
      fill_level: "live",
      gas_value: "live",
      status: "Live",
      date: new Date().toISOString(),
    },
  ]);
});

/* ---------------- ALERTS ---------------- */
app.get("/api/dustbin/alerts", async (req, res) => {
  try {
    const { data } = await axios.get(
      `${ESP32_BASE_URL}/api/dustbin/status/1`
    );

    const alerts = [];

    if (data.fill_level > 80) {
      alerts.push({
        id: 1,
        type: "warning",
        message: "Dustbin nearly full",
        timestamp: "now",
      });
    }

    if (data.gas_status !== "Safe") {
      alerts.push({
        id: 2,
        type: "critical",
        message: "Gas level dangerous",
        timestamp: "now",
      });
    }

    res.json(alerts);
  } catch (err) {
    res.json([]);
  }
});

/* ---------------- START ---------------- */
app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
