#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

/* ------------------- WIFI ------------------- */
const char* ssid = "Rajpoots";
const char* password = "Taqdees@433";

/* ------------------- SERVER ------------------- */
WebServer server(80);

/* ------------------- OLED ------------------- */
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

/* ------------------- PINS ------------------- */
#define TRIG_PIN 5
#define ECHO_PIN 18
#define MQ2_PIN 34
#define LED_PIN 2

/* ------------------- BIN CONFIG ------------------- */
float BIN_DEPTH_CM = 20.0;   // adjust to your dustbin depth

/* ------------------- GLOBAL DATA ------------------- */
float fillPercentage = 0.0;
int gasValue = 0;

/* ------------------- FUNCTIONS ------------------- */

float readDistanceCM() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return BIN_DEPTH_CM;

  float distance = duration * 0.034 / 2;
  return constrain(distance, 0, BIN_DEPTH_CM);
}

void drawBootScreen() {
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(10, 10);
  display.println("SMART BIN");

  display.drawRect(10, 45, 108, 10, SSD1306_WHITE);

  for (int i = 0; i <= 100; i += 5) {
    display.fillRect(12, 47, i, 6, SSD1306_WHITE);
    display.display();
    delay(40);
  }

  delay(400);
}

void updateOLED() {
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(0, 0);
  display.print("Fill: ");
  display.print(fillPercentage, 1);
  display.println("%");

  display.print("Gas: ");
  display.println(gasValue);

  if (fillPercentage > 80 || gasValue > 300) {
    display.setTextColor(SSD1306_WHITE);
    display.println("STATUS: ALERT");
  } else {
    display.println("STATUS: SAFE");
  }

  display.display();
}

/* ------------------- API HANDLERS ------------------- */

void handleStatus() {
  String gasStatus = "Safe";
  if (gasValue > 300) gasStatus = "Critical";
  else if (gasValue > 150) gasStatus = "Warning";

  String json = "{";
  json += "\"id\":1,";
  json += "\"fill_level\":" + String(fillPercentage, 1) + ",";
  json += "\"gas_value\":" + String(gasValue) + ",";
  json += "\"gas_status\":\"" + gasStatus + "\",";
  json += "\"battery\":100,";
  json += "\"wifi_status\":\"Connected\",";
  json += "\"signal_strength\":\"Good\",";
  json += "\"updated_at\":\"now\",";
  json += "\"last_sync\":\"live\"";
  json += "}";

  server.send(200, "application/json", json);
}

void handleLogs() {
  String json = "[{";
  json += "\"id\":1,";
  json += "\"timestamp\":\"now\",";
  json += "\"fill_level\":" + String(fillPercentage,1) + ",";
  json += "\"gas_value\":" + String(gasValue) + ",";
  json += "\"status\":\"Live\",";
  json += "\"date\":\"today\"";
  json += "}]";

  server.send(200, "application/json", json);
}

void handleAlerts() {
  String json = "[";

  if (fillPercentage > 80 || gasValue > 300) {
    json += "{";
    json += "\"id\":1,";
    json += "\"type\":\"critical\",";
    json += "\"message\":\"Immediate attention required\",";
    json += "\"timestamp\":\"now\"";
    json += "}";
  }

  json += "]";
  server.send(200, "application/json", json);
}

/* ------------------- SETUP ------------------- */
void setup() {
  Serial.begin(115200);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);

  Wire.begin(21, 22);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  drawBootScreen();

  WiFi.begin(ssid, password);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected! IP: " + WiFi.localIP().toString());

  server.on("/api/dustbin/status/1", handleStatus);
  server.on("/api/dustbin/logs/1", handleLogs);
  server.on("/api/dustbin/alerts", handleAlerts);
  server.begin();
}

/* ------------------- LOOP ------------------- */
void loop() {
  server.handleClient();

  float distance = readDistanceCM();
  fillPercentage = ((BIN_DEPTH_CM - distance) / BIN_DEPTH_CM) * 100.0;
  fillPercentage = constrain(fillPercentage, 0, 100);

  gasValue = analogRead(MQ2_PIN);

  digitalWrite(LED_PIN, (fillPercentage > 80 || gasValue > 300));

  updateOLED();

  Serial.print("Fill: ");
  Serial.print(fillPercentage);
  Serial.print("%  Gas: ");
  Serial.println(gasValue);

  delay(1500);
}
